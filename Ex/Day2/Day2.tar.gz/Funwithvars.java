/**
* This is a sample class for swapping two integer values.
*	@author Nicholas Loftin (nlloftin@ncsu.edu)
*	Version 1 :)
**/	
public class Funwithvars{
public static void main(String[] args){


	double dub = 67.12;
	int cast;
		System.out.println("The original number was... " + dub);
	cast = (int)dub;
	System.out.println("The new variable as an int is: " + cast); 	

	








}




}


