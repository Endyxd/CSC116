import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class MyActionListener implements ActionListener{

	public void actionPerformed(ActionEvent event){
		JOptionPane.showMessageDialog(null,"An event occurred!");
	}
}