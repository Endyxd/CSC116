import java.util.*;
import java.io.*;

public class calendar{

   public static int JAN = 1;
    /** days per week */
   public static final int DAYS_PER_WEEK = 7;
    
    /** leap year century */
   public static final int LEAP_YEAR_CENTURY = 400; // leap year century
    /** months per year */
   public static final int MONTHS_PER_YEAR = 12; //months per year
    /** days per month */
   public static final int DAYS_PER_MONTH = 31; //days per month
        /**frequency of each leap year*/
   public static final int LEAP_YEAR_FREQUENCY = 4;

   public static void calendarCreate(int year){
      boolean leapYear;
      if (year % 4 == 0){
         leapYear = true;
      }else
         leapYear = false;
      String day = getDates(year);
      if(day.equals("Sunday")){
         startCalendar(1);  
      }else if(day.equals("Monday")){
         startCalendar(2);
      }else if(day.equals("Tuesday")){
         startCalendar(3);
      }else if(day.equals("Wednesday")){
         startCalendar(4);
      }else if(day.equals("Thursday")){
         startCalendar(5);
      }else if(day.equals("Friday")){
         startCalendar(6);
      }else if(day.equals("Saturday")){
         startCalendar(7);
      }
     
   }
   public static void startCalendar(int startDay){
      int month = 1;
      int day = 1;
      System.out.println("        " + getMonth(month) + "        ");
   
      if(startDay != 1){
         for(int i = 1; i < startDay; i++){
            System.out.printf("%4s", "-");
         }
      }
      boolean first = true;
      do{
        if(first == true){
            //put the first week exception here and put hte rest below
            first = false;
        }
         
         
         System.out.printf("%4d", day);
         System.out.printf("%4d", day+1);
         System.out.printf("%4d", day+2);
         System.out.printf("%4d", day+3);
         System.out.printf("%4d", day+4);
         System.out.printf("%4d", day+5);
         System.out.printf("%4d", day+6);
         
         
         System.out.println();
         
         
         
         day+=5;
      }while(day <= 31);
   }
   public static String getMonth(int month){
      if(month == 1)
         return "January";
      else if(month == 2)
         return "Febuary";
      else if(month ==3)
         return "March";
      else if(month == 4)
         return "April";
      else if(month == 5)
         return "May";
      else if(month == 6)
         return "June";
      else if(month == 7)
         return "July";
      else if(month == 8)
         return "August";
      else if(month == 9)
         return "September";
      else if(month == 10)
         return "October";
      else if(month == 11)
         return "November";
      else if(month == 12)
         return "December";
      return "null";
   }
   
   public static String getDates(int year) {
      double x;
      double w;
      int y = year;
      double z;
      int m = JAN;
      int d = JAN;
      double dayOfWeek;      
      w = y - (14 - m) / MONTHS_PER_YEAR;
      
      x = w + w / LEAP_YEAR_FREQUENCY - w / 100 + w / LEAP_YEAR_CENTURY;
      
      z = m + MONTHS_PER_YEAR * ((14 - m) / MONTHS_PER_YEAR) - 2;
      
      
      dayOfWeek = (d + x + (DAYS_PER_MONTH * z) / MONTHS_PER_YEAR) % DAYS_PER_WEEK;
         //System.out.println(dayOfWeek);
      dayOfWeek = (int) dayOfWeek;
         //System.out.println(dayOfWeek);
      
      if (dayOfWeek == 0)
         return "Sunday";
      else if (dayOfWeek == 1)
         return "Monday";
      else if (dayOfWeek == 2)
         return "Tuesday";
      else if (dayOfWeek == 3)
         return "Wednesday";
      else if (dayOfWeek == 4)
         return "Thursday";
      else if (dayOfWeek == 5)
         return "Friday";
      else if (dayOfWeek == 6)
         return "Saturday";
      throw new IllegalArgumentException("Invalid date");
         //System.exit(1);
         //return "null";
      
   }
   

}